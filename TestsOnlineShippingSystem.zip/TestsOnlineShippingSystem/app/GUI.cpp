class GUI
{
private:
	// Members

public:
	GUI();

};

GUI::GUI() {

}